# ============================================================
# STUDENT PERFORMANCE PREDICTION – PHASE 2
# Naïve Bayes + Decision Tree + Performance Evaluation
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Optional seaborn
try:
    import seaborn as sns
    USE_SEABORN = True
except ImportError:
    USE_SEABORN = False

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier

# =========================
# 1. LOAD DATA
# =========================

df = pd.read_csv("student_data.csv")

# Create target variable (Pass = 1, Fail = 0)
df["Result"] = df["G3"].apply(lambda x: 1 if x >= 10 else 0)

# Drop grade columns
df.drop(columns=["G1", "G2", "G3"], inplace=True)

# One-hot encoding
df = pd.get_dummies(df, drop_first=True)

X = df.drop(columns=["Result"])
y = df["Result"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# =========================
# 2. NAÏVE BAYES MODEL
# =========================

nb_model = GaussianNB()
nb_model.fit(X_train, y_train)

y_train_pred_nb = nb_model.predict(X_train)
y_test_pred_nb = nb_model.predict(X_test)

# =========================
# 3. DECISION TREE (COMPARISON)
# =========================

dt_model = DecisionTreeClassifier(max_depth=3, random_state=42)
dt_model.fit(X_train, y_train)

y_train_pred_dt = dt_model.predict(X_train)
y_test_pred_dt = dt_model.predict(X_test)

# =========================
# 4. PERFORMANCE METRICS
# =========================

results = [
    {
        "Model": "Naïve Bayes",
        "Train Accuracy": round(accuracy_score(y_train, y_train_pred_nb), 3),
        "Test Accuracy": round(accuracy_score(y_test, y_test_pred_nb), 3),
        "Precision": round(precision_score(y_test, y_test_pred_nb), 3),
        "Recall": round(recall_score(y_test, y_test_pred_nb), 3),
        "F1-Score": round(f1_score(y_test, y_test_pred_nb), 3)
    },
    {
        "Model": "Decision Tree",
        "Train Accuracy": round(accuracy_score(y_train, y_train_pred_dt), 3),
        "Test Accuracy": round(accuracy_score(y_test, y_test_pred_dt), 3),
        "Precision": round(precision_score(y_test, y_test_pred_dt), 3),
        "Recall": round(recall_score(y_test, y_test_pred_dt), 3),
        "F1-Score": round(f1_score(y_test, y_test_pred_dt), 3)
    }
]

results_df = pd.DataFrame(results)

print("\nPHASE 2 – MODEL COMPARISON (STUDENT PERFORMANCE)\n")
print(results_df.to_string(index=False))

# =========================
# 5. CONFUSION MATRIX (NAÏVE BAYES)
# =========================

cm = confusion_matrix(y_test, y_test_pred_nb)

if USE_SEABORN:
    plt.figure(figsize=(6,4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Fail","Pass"],
                yticklabels=["Fail","Pass"])
    plt.title("Confusion Matrix – Naïve Bayes")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()
else:
    plt.imshow(cm, cmap="Blues")
    plt.colorbar()
    plt.xticks([0,1], ["Fail","Pass"])
    plt.yticks([0,1], ["Fail","Pass"])
    for i in range(2):
        for j in range(2):
            plt.text(j, i, cm[i, j], ha="center", va="center", color="red")
    plt.title("Confusion Matrix – Naïve Bayes")
    plt.show()

print("\n✅ Phase 2 outputs generated successfully")
