# ============================================================
# FINAL STUDENT PERFORMANCE PROJECT CODE
# Scratch Tree + Sklearn/Ensemble + Train/Test Accuracy
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter

# Optional seaborn
try:
    import seaborn as sns
    USE_SEABORN = True
except ImportError:
    USE_SEABORN = False

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

# =========================
# 1. LOAD DATA
# =========================

df = pd.read_csv("student_data.csv")
df["Result"] = df["G3"].apply(lambda x: 1 if x >= 10 else 0)
df.drop(columns=["G1", "G2", "G3"], inplace=True)
df = pd.get_dummies(df, drop_first=True)

X = df.drop(columns=["Result"])
y = df["Result"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# =========================
# 2. SCRATCH DECISION TREE
# =========================

def entropy(y):
    counts = np.bincount(y)
    probs = counts / len(y)
    return -np.sum([p * np.log2(p) for p in probs if p > 0])

def info_gain(X_col, y):
    parent_entropy = entropy(y)
    values, counts = np.unique(X_col, return_counts=True)
    weighted_entropy = sum((c/len(y))*entropy(y[X_col==v]) for v,c in zip(values,counts))
    return parent_entropy - weighted_entropy

class MyDecisionTree:
    def __init__(self, depth=3):
        self.depth = depth

    def fit(self, X, y, d=0):
        if len(set(y)) == 1 or d == self.depth:
            return Counter(y).most_common(1)[0][0]

        gains = [info_gain(X[:, i], y) for i in range(X.shape[1])]
        best_feat = np.argmax(gains)

        tree = {best_feat: {}}
        for v in np.unique(X[:, best_feat]):
            tree[best_feat][v] = self.fit(
                X[X[:, best_feat]==v],
                y[X[:, best_feat]==v],
                d+1
            )
        return tree

    def predict(self, X, tree):
        def pred_one(x, t):
            if not isinstance(t, dict):
                return t
            feat = list(t.keys())[0]
            return pred_one(x, t[feat].get(x[feat], 0))
        return np.array([pred_one(row, tree) for row in X])

scratch_model = MyDecisionTree(depth=3)
scratch_tree = scratch_model.fit(X_train.values, y_train.values)
y_pred_scratch_train = scratch_model.predict(X_train.values, scratch_tree)
y_pred_scratch_test = scratch_model.predict(X_test.values, scratch_tree)

# =========================
# 3. SKLEARN & ENSEMBLE MODELS
# =========================

models = {
    "Scratch Tree": (y_pred_scratch_train, y_pred_scratch_test),
    "Decision Tree": lambda X_train, y_train: DecisionTreeClassifier(max_depth=3, random_state=42).fit(X_train, y_train),
    "Random Forest": lambda X_train, y_train: RandomForestClassifier(random_state=42).fit(X_train, y_train),
    "Extra Trees": lambda X_train, y_train: ExtraTreesClassifier(random_state=42).fit(X_train, y_train),
    "Gradient Boosting": lambda X_train, y_train: GradientBoostingClassifier(random_state=42).fit(X_train, y_train),
    "XGBoost": lambda X_train, y_train: XGBClassifier(eval_metric="logloss", use_label_encoder=False).fit(X_train, y_train),
    "LightGBM": lambda X_train, y_train: LGBMClassifier(verbose=-1).fit(X_train, y_train),
    "CatBoost": lambda X_train, y_train: CatBoostClassifier(iterations=200, depth=4, verbose=0).fit(X_train, y_train)
}

# =========================
# 4. TRAIN & TEST PREDICTIONS + METRICS
# =========================

results = []

for name, model in models.items():
    if name == "Scratch Tree":
        y_train_pred, y_test_pred = model
    else:
        m = model(X_train, y_train)
        y_train_pred = m.predict(X_train)
        y_test_pred = m.predict(X_test)

    results.append({
        "Model": name,
        "Train Accuracy": round(accuracy_score(y_train, y_train_pred), 3),
        "Test Accuracy": round(accuracy_score(y_test, y_test_pred), 3),
        "Precision": round(precision_score(y_test, y_test_pred), 3),
        "Recall": round(recall_score(y_test, y_test_pred), 3),
        "F1-Score": round(f1_score(y_test, y_test_pred), 3)
    })

results_df = pd.DataFrame(results)
print("\nFINAL MODEL METRICS (Train & Test)\n")
print(results_df.to_string(index=False))

# =========================
# 5. CONFUSION MATRIX (Scratch Tree)
# =========================

cm = confusion_matrix(y_test, y_pred_scratch_test)

if USE_SEABORN:
    plt.figure(figsize=(6,4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Fail","Pass"], yticklabels=["Fail","Pass"])
    plt.title("Confusion Matrix - Scratch Tree")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.savefig("confusion_matrix.png")
    plt.show()
else:
    plt.imshow(cm, cmap='Blues')
    plt.colorbar()
    plt.xticks([0,1], ["Fail","Pass"])
    plt.yticks([0,1], ["Fail","Pass"])
    for i in range(2):
        for j in range(2):
            plt.text(j, i, cm[i,j], ha='center', va='center', color='red')
    plt.title("Confusion Matrix - Scratch Tree")
    plt.show()

# =========================
# 6. DECISION TREE VISUALIZATION (Sklearn)
# =========================

plt.figure(figsize=(20,10))
dt = DecisionTreeClassifier(max_depth=3, random_state=42)
dt.fit(X_train, y_train)
plot_tree(dt, filled=True, feature_names=X.columns, class_names=["Fail","Pass"], fontsize=10)
plt.title("Decision Tree Visualization")
plt.savefig("tree_visualization.png")
plt.show()

print("\n✅ All outputs saved: confusion_matrix.png & tree_visualization.png")
